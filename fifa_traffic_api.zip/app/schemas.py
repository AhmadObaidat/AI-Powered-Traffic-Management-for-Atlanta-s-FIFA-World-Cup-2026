from pydantic import BaseModel, Field


class TrafficFeatures(BaseModel):
    hour_sin: float
    hour_cos: float
    dow_sin: float
    dow_cos: float
    month_sin: float
    month_cos: float
    is_match_day: int = Field(ge=0, le=1)
    is_weekend: int = Field(ge=0, le=1)
    is_rush_hour: int = Field(ge=0, le=1)
    in_event_window: int = Field(ge=0, le=1)
    hours_to_kickoff: float
    is_raining: int = Field(ge=0, le=1)
    temperature_c: float
    precipitation_mm: float = Field(ge=0)
    windspeed_kmh: float = Field(ge=0)
    humidity_pct: float = Field(ge=0, le=100)
    lag_1h: float = Field(ge=0, description="Traffic 1 hour ago (veh/h)")
    lag_24h: float = Field(ge=0, description="Traffic 24 hours ago (veh/h)")
    lag_168h: float = Field(ge=0, description="Traffic 1 week ago (veh/h)")
    roll_mean_24h: float = Field(ge=0)
    roll_std_24h: float = Field(ge=0)
    roll_max_24h: float = Field(ge=0)


class Prediction(BaseModel):
    predicted_volume_veh_per_hour: float
    risk_level: str
    recommended_action: str
    model_version: str
