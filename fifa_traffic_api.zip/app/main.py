import json
from pathlib import Path

import pandas as pd
import xgboost as xgb
from fastapi import FastAPI

from app.schemas import Prediction, TrafficFeatures

BASE = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE / "models" / "xgb_traffic_model.json"
CONFIG = json.load(open(BASE / "models" / "model_config.json"))
SAMPLES = json.load(open(BASE / "models" / "sample_requests.json"))

FEATURES = CONFIG["features"]
MODERATE = CONFIG["moderate_threshold"]
HIGH = CONFIG["high_threshold"]
MODEL_VERSION = "xgb-v1"

ACTIONS = {
    "LOW": "Normal operations.",
    "MODERATE": "Activate dynamic message signs; add MARTA rail frequency.",
    "HIGH": "Deploy traffic officers, open contraflow/shoulder lanes, maximize MARTA service, push driver alerts.",
}

app = FastAPI(
    title="Atlanta FIFA 2026 Traffic Forecast API",
    description="Predicts hourly traffic volume near Mercedes-Benz Stadium and returns a risk level.",
    version="1.0.0",
)

model = xgb.XGBRegressor()
model.load_model(MODEL_PATH)


def risk_level(volume: float) -> str:
    if volume >= HIGH:
        return "HIGH"
    if volume >= MODERATE:
        return "MODERATE"
    return "LOW"


def make_prediction(volume: float) -> Prediction:
    level = risk_level(volume)
    return Prediction(
        predicted_volume_veh_per_hour=round(volume, 1),
        risk_level=level,
        recommended_action=ACTIONS[level],
        model_version=MODEL_VERSION,
    )


@app.get("/health")
def health():
    return {"status": "ok", "model_version": MODEL_VERSION}


@app.get("/thresholds")
def thresholds():
    return {"moderate_veh_per_hour": MODERATE, "high_veh_per_hour": HIGH}


@app.get("/sample")
def sample():
    """Real rows from the dataset you can copy into /predict."""
    return SAMPLES


@app.post("/predict", response_model=Prediction)
def predict(features: TrafficFeatures):
    row = pd.DataFrame([features.model_dump()])[FEATURES]
    return make_prediction(float(model.predict(row)[0]))


@app.post("/predict/batch", response_model=list[Prediction])
def predict_batch(items: list[TrafficFeatures]):
    rows = pd.DataFrame([i.model_dump() for i in items])[FEATURES]
    return [make_prediction(float(v)) for v in model.predict(rows)]
