import json
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
SAMPLES = json.load(open("models/sample_requests.json"))
MATCH = SAMPLES["match_day"]["request"]
NORMAL = SAMPLES["regular_day"]["request"]


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_predict_match_day():
    r = client.post("/predict", json=MATCH)
    assert r.status_code == 200
    assert r.json()["risk_level"] in {"LOW", "MODERATE", "HIGH"}


def test_match_day_higher_than_regular():
    m = client.post("/predict", json=MATCH).json()["predicted_volume_veh_per_hour"]
    n = client.post("/predict", json=NORMAL).json()["predicted_volume_veh_per_hour"]
    assert m != n


def test_batch():
    r = client.post("/predict/batch", json=[MATCH, NORMAL])
    assert r.status_code == 200
    assert len(r.json()) == 2


def test_bad_input_rejected():
    r = client.post("/predict", json={**MATCH, "humidity_pct": 500})
    assert r.status_code == 422


def test_missing_field_rejected():
    bad = dict(MATCH)
    bad.pop("lag_1h")
    r = client.post("/predict", json=bad)
    assert r.status_code == 422
